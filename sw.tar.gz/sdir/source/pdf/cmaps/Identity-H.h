/* This is an automatically generated file. Do not edit. */

/* Identity-H */

static const pdf_range cmap_Identity_H_ranges[] = {
{0x0,0xffff,0x0},
};

static pdf_cmap cmap_Identity_H = {
	{ -1, pdf_drop_cmap_imp },
	/* cmapname */ "Identity-H",
	/* usecmap */ "", NULL,
	/* wmode */ 0,
	/* codespaces */ 1, {
		{ 2, 0x0000, 0xffff },
	},
	1, 1, (pdf_range*)cmap_Identity_H_ranges,
	0, 0, NULL, /* xranges */
	0, 0, NULL, /* mranges */
	0, 0, NULL, /* table */
	0, 0, 0, NULL /* splay tree */
};
